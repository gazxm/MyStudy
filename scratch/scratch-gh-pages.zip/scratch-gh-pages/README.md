# scratch
一个HTML5实现的刮奖效果

DEMO：[http://lwzhang.github.io/scratch/scratch.html](http://lwzhang.github.io/scratch/scratch.html)
