import { combineReducers } from 'redux'

import securityFund from './securityFundReducer'

export default combineReducers({
  securityFund
})
