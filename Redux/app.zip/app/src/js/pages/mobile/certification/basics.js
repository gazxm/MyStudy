/* eslint-disable */
export default [{
    id: 1,
    name: 'information',
    link: '/mobile/certification/information'
}, {
    id: 3,
    name: 'contacts',
    link: '/mobile/certification/contacts'
}, {
    id: 4,
    name: 'bank',
    link: '/mobile/certification/bank'
}, {
    id: 5,
    name: 'operator',
    link: '/mobile/certification/operator'
}, {
    id: 2,
    name: 'jobs',
    link: '/mobile/certification/jobs'
}];