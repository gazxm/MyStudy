export default [{
  id: 1,
  name: 'information',
  link: '/channel/m/certification/information'
}, {
  id: 3,
  name: 'contacts',
  link: '/channel/m/certification/contacts'
}, {
  id: 5,
  name: 'operator',
  link: '/channel/m/certification/operator'
}, {
  id: 4,
  name: 'bank',
  link: '/channel/m/certification/bank'
}]
